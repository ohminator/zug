

import sum.kern.*;
    
public class Lokomotive extends Waggon
{       
    public Lokomotive(double pHPosition, double pVPosition)
    {
        super(pHPosition,pVPosition);
    }

    public void zeichne()
    { 
    // Puffer links
        hatStift.hoch();
        hatStift.bewegeBis(this.hPosition(),this.vPosition());
        hatStift.runter();
        hatStift.dreheBis(90); //oben
        hatStift.bewegeUm(3);
        hatStift.dreheUm(180); //unten
        hatStift.bewegeUm(6);
        hatStift.dreheUm(180); //oben
        hatStift.bewegeUm(3);
        hatStift.dreheUm(270); //rechts
        hatStift.bewegeUm(5);
        
        // Vorderteil
        hatStift.hoch();
        hatStift.dreheUm(90); //oben
        hatStift.bewegeUm(20);
        hatStift.zeichneRechteck(50,25);
        
        // Schornstein
        hatStift.bewegeUm(15);
        hatStift.dreheUm(-90); //rechts
        hatStift.bewegeUm(10);
        hatStift.zeichneRechteck(5,15);
        
        // Fuehrerhaus
        hatStift.bewegeUm(40);
        hatStift.dreheUm(90); //oben
        hatStift.bewegeUm(10);
        hatStift.zeichneRechteck(30,50);
        
        // Fenster
        hatStift.bewegeUm(-5);
        hatStift.dreheUm(-90); //rechts
        hatStift.bewegeUm(5);
        hatStift.zeichneRechteck(20,20);
        
        // Raeder
        hatStift.dreheUm(-90); //unten
        hatStift.bewegeUm(50);
        hatStift.dreheUm(90); //rechts
        hatStift.bewegeUm(15);
        hatStift.zeichneKreis(5);
        hatStift.bewegeUm(-60);
        hatStift.zeichneKreis(5);
        
        // Puffer rechts
        hatStift.bewegeUm(70);
        hatStift.dreheUm(90); //oben
        hatStift.bewegeUm(10);
        hatStift.runter();
        hatStift.dreheUm(270); //rechts
        hatStift.bewegeUm(5);
        hatStift.dreheUm(90); //oben
        hatStift.bewegeUm(3);
        hatStift.dreheUm(180); //unten
        hatStift.bewegeUm(6);
        hatStift.dreheUm(180); //oben
        hatStift.bewegeUm(3);
    }
    
}

