

import sum.kern.*;

public abstract class Waggon
{       
    double zHPosition, zVPosition;
    Stift hatStift;

    // Konstruktor
    public Waggon(double pHPosition, double pVPosition)
    {
        zHPosition = pHPosition; zVPosition = pVPosition;
        hatStift = new Buntstift();
        hatStift.bewegeBis(pHPosition, pVPosition);
        this.zeichne();
    }
    
    public abstract void zeichne();

    public void loesche()
    {
        hatStift.radiere();
        this.zeichne();
        hatStift.normal();
    }
    
    public void bewegeUm(double pDistanz)
    {
        this.loesche();
        zHPosition = zHPosition - pDistanz;
        this.zeichne();
        
    }
    
    public double hPosition()
    {
        return zHPosition;
    }       
    
    public double vPosition()
    {
        return zVPosition;
    }       

}

