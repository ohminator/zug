import sum.kern.*;
    
public class Zugprogramm
{       
    public static void main(String[] args)
    { 
        //Hier bitte Quelltext einfuegen
    }
}

