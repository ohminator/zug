
import sum.kern.*;
/**
 * @Maximilian Köper
 * @12.06.2025
 */
public abstract class Waggon
{
    // Objekte
    Buntstift hatStift;
    double zDistanz;
    double zHPosition;
    double zVPosition;
    
    // Konstruktor
    public Waggon(double pDistanz, double pHPosition, double pVPosition)
    {
        hatStift = new Buntstift();
        zDistanz = pDistanz;
        zHPosition = pHPosition;
        zVPosition = pVPosition;
    }

    // Dienste
    public abstract void zeichne();
    
    public void loesche()
    {
        hatStift.radiere();
        this.zeichne();
        hatStift.normal();
    }
    
    public void bewegeUm(double pDistanz)
    {
        this.loesche();
        hatStift.bewegeUm(pDistanz);
        this.zeichne();
    }
    
    double hPosition()
    {
        return this.hPosition();
    }
    
    double vPosition()
    {
        return this.vPosition();
    }
    
    public void gibFrei()
    {
        hatStift.gibFrei();
    }
}