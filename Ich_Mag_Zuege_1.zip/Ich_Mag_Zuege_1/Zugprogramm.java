
import sum.kern.*;
/**
 * @author 
 * @version 
 */
public class Zugprogramm
{
    public static void main(String[] s)
    {
        //Initialisierung und Deklaration
        Bildschirm meinBildschirm = new Bildschirm();
        Maus dieMaus = new Maus();
        
        Lok meineLok = new Lok(500, 400);
        Perso meinPerso = new Perso();
        Gut meinGut = new Gut();
        
        
        //Aktion
        while(!dieMaus.istDoppelklick())
        {
            meineLok.bewewgeUm(0.2);
            meinPerso.bewegeUm(0.2);
            meinGut.bewegeUm(0.2);
        }
        
        
        //Aufräumen
        meinBildschirm.gibFrei();
        dieMaus.gibFrei();
        meineLok.gibFrei();
        meinPerso.gibFrei();
        meinGut.gibFrei();
}